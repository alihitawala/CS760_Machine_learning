#!/usr/bin/env bash
/s/python-2.7.3/bin/python Bayes.py $1 $2 $3